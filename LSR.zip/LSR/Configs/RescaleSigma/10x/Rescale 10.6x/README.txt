README
For 1x or 10x scale, change the .txt documents into .cfg documents and back again when not needed. Do not have both scales active at the same time.